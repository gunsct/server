#include "packet.h"

packet::packet(){
	name[0] = 0;
	classOneName[0] = 0;
	classTwoName[0] = 0;
	scoreOne = 0;
	scoreTwo = 0;
};