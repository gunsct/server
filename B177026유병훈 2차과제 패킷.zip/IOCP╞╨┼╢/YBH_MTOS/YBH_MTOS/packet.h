class packet{
public:
	packet();
	~packet(){}

	char name[10];
	char classOneName[20];
	char classTwoName[20];
	int scoreOne;
	int scoreTwo;
};