#pragma once

#include "Network.h"

void main( int argc, char* argv[] )
{
	NetWork	sock;
	sock.Run();
}